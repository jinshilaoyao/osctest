
class LoginEvent {

}