import 'package:flutter/material.dart';

class ChangeThemeEvent {

  Color color;

  ChangeThemeEvent(this.color);
}